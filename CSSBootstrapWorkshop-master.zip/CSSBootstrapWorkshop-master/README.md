# CSSBootstrapWorkshop

# There are 2 projects :

1. coffee_shop_template - starter project
2. coffee_shop_final - final project

# Resorces :

## During the workshop I will use VSC ide.

Please see below links to download VSC and some usefull plugins to speed up web development.

## Download VSCode (https://code.visualstudio.com/)

### VSC plugins

IntelliSense for CSS class names in HTML https://marketplace.visualstudio.com/items?itemName=Zignd.html-css-class-completion -- CSS class name completion for the HTML class attribute based on the definitions found in your workspace

Live Server https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer -- Launch a development local Server with live reload feature for static & dynamic pages

Path Autocomplete https://marketplace.visualstudio.com/items?itemName=ionutvmi.path-autocomplete -- Provides path completion for visual studio code.

HTML CSS Support https://marketplace.visualstudio.com/items?itemName=ecmel.vscode-html-css -- CSS support for HTML documents

## Bootstrap links

Get Bootstrap: https://getbootstrap.com/

Bootstrap 4 Cheat Sheet https://bootstrapcreative.com/resources/bootstrap-4-css-classes-index/

font awesome: https://www.bootstrapcdn.com/fontawesome/

## CSS 
Learn CSS layout - https://learnlayout.com/display.html
Fonts: https://fonts.google.com
https://www.w3schools.com/css

## Images links

Free images: https://pixabay.com/
